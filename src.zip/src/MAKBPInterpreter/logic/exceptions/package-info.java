/**
 * This package defines the exception for {@link MAKBPInterpreter.logic}
 * package and other packages that use the {@link MAKBPInterpreter.logic}
 * package.
 * 
 * @author Guillaume LETELLIER, Corentin PIERRE
 */
package MAKBPInterpreter.logic.exceptions;
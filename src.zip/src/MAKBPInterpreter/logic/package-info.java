/**
 * This package defines the basis of the propositionnal logic.
 * 
 * @author Guillaume LETELLIER, Corentin PIERRE
 */
package MAKBPInterpreter.logic;
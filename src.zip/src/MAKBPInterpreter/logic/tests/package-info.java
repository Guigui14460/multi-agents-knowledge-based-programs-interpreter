/**
 * This package defines the tests of the
 * {@link MAKBPInterpreter.logic} package.
 * 
 * @author Guillaume LETELLIER, Corentin PIERRE
 */
package MAKBPInterpreter.logic.tests;

package MAKBPInterpreter.logic;

/**
 * Represents a logic assignment for a formula evaluation.
 */
public interface LogicAssignment {
}

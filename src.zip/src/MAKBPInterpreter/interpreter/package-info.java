/**
 * This package defines the interpreter of a
 * Multi-Agent Knowledge-Based Program.
 * 
 * @author Guillaume LETELLIER, Corentin PIERRE
 */
package MAKBPInterpreter.interpreter;
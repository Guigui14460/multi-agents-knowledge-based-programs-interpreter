/**
 * This package defines the tests of the
 * {@link MAKBPInterpreter.interpreter} package.
 * 
 * @author Guillaume LETELLIER, Corentin PIERRE
 */
package MAKBPInterpreter.interpreter.tests;

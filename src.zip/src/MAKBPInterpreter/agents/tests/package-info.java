/**
 * This package defines the tests of the
 * {@link MAKBPInterpreter.agents} package.
 * 
 * @author Guillaume LETELLIER, Corentin PIERRE
 */
package MAKBPInterpreter.agents.tests;

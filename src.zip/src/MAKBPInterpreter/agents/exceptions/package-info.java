/**
 * This package defines the exception for {@link MAKBPInterpreter.agents}
 * package and other packages that use the {@link MAKBPInterpreter.agents}
 * package.
 * 
 * @author Guillaume LETELLIER, Corentin PIERRE
 */
package MAKBPInterpreter.agents.exceptions;
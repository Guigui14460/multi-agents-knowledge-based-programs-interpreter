/**
 * This package defines the basis of the agents, memory, observation, etc.
 * 
 * @author Guillaume LETELLIER, Corentin PIERRE
 */
package MAKBPInterpreter.agents;